'use strict';
const $ = s => document.querySelector(s);
const ls = chrome.storage.local, DNR = chrome.declarativeNetRequest;
const BASE = 1000000;
const TYPES = ['sub_frame', 'script', 'image', 'stylesheet', 'font', 'media', 'xmlhttprequest', 'ping', 'websocket', 'other'];
const RULESETS = ['requests', 'cookie-banners-requests', 'filter1-requests'];
const BACKUP_KEYS = ['userData', 'deactivatedSites', 'cookieBannersAllowedSites', 'popupAllowedSites', 'customCssRules', 'statistics', 'proRules'];
let logTimer = null;

function setMsg(id, text, err) { const e = $(id); e.textContent = text; e.className = 'msg' + (err ? ' err' : ''); }
function show(id) {
  document.querySelectorAll('section').forEach(s => { s.hidden = s.id !== id; });
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.tab === id));
  clearInterval(logTimer);
  if (id === 'log') { renderLog(); logTimer = setInterval(renderLog, 2000); }
  if (id === 'pause') renderPause();
}
document.querySelectorAll('nav button').forEach(b => { b.onclick = () => show(b.dataset.tab); });

// ---------- custom rules ----------
function parseRules(text) {
  const network = [], cosmetic = [], errors = [];
  text.split(/\r?\n/).forEach((raw, i) => {
    const line = raw.trim();
    if (!line || line.startsWith('!')) return;
    const c = line.indexOf('##');
    if (c !== -1) {
      const selector = line.slice(c + 2).trim();
      const domains = line.slice(0, c).split(',').map(d => d.trim().toLowerCase()).filter(Boolean);
      try {
        if (!selector || /[{}]/.test(selector)) throw new Error('bad');
        document.createDocumentFragment().querySelector(selector);
      } catch (e) { errors.push('line ' + (i + 1) + ' (invalid selector)'); return; }
      cosmetic.push({ domains, selector });
      return;
    }
    const allow = line.startsWith('@@');
    const pattern = (allow ? line.slice(2) : line).trim();
    if (!pattern) { errors.push('line ' + (i + 1) + ' (empty)'); return; }
    network.push({ allow, pattern });
  });
  return { network, cosmetic, errors };
}
async function applyRules(text) {
  const { network, cosmetic, errors } = parseRules(text);
  if (network.length > 3000) return { ok: false, msg: 'Too many network rules (max 3000).' };
  const old = (await DNR.getDynamicRules()).filter(r => r.id >= BASE).map(r => r.id);
  const addRules = network.map((r, i) => ({
    id: BASE + i, priority: r.allow ? 10000 : 1, action: { type: r.allow ? 'allow' : 'block' },
    condition: { urlFilter: r.pattern, isUrlFilterCaseSensitive: false, resourceTypes: TYPES }
  }));
  try { await DNR.updateDynamicRules({ removeRuleIds: old, addRules }); }
  catch (e) { return { ok: false, msg: 'Chrome rejected a rule: ' + e.message }; }
  await ls.set({ proRules: { text, cosmetic } });
  return { ok: true, msg: 'Saved ' + network.length + ' network and ' + cosmetic.length + ' hide rules.' + (errors.length ? ' Skipped: ' + errors.join(', ') : '') };
}
$('#saveRules').onclick = async () => { const r = await applyRules($('#rulesText').value); setMsg('#rulesMsg', r.msg, !r.ok); };
$('#clearRules').onclick = async () => { $('#rulesText').value = ''; const r = await applyRules(''); setMsg('#rulesMsg', r.ok ? 'All custom rules removed.' : r.msg, !r.ok); };
ls.get('proRules').then(d => { $('#rulesText').value = d.proRules?.text || ''; });

// ---------- pause ----------
async function renderPause() {
  const { proPause } = await ls.get('proPause');
  $('#pauseStatus').textContent = !proPause ? 'Blocking is ON.' :
    proPause.until ? 'Blocking is PAUSED until ' + new Date(proPause.until).toLocaleTimeString() + '.' : 'Blocking is PAUSED until you resume.';
}
async function pause(min) {
  await DNR.updateEnabledRulesets({ disableRulesetIds: RULESETS });
  const until = min ? Date.now() + min * 60000 : 0;
  await ls.set({ proPause: { until } });
  if (min) chrome.alarms.create('pro-resume', { when: until }); else chrome.alarms.clear('pro-resume');
  renderPause();
}
async function resume() {
  const { userData } = await ls.get('userData');
  const s = userData?.settings || {};
  const on = [];
  if (s.enabled !== false) on.push('requests');
  if (s.hideCookieBanners) on.push('cookie-banners-requests');
  if (s.blockMalicious) on.push('filter1-requests');
  await DNR.updateEnabledRulesets({ enableRulesetIds: on, disableRulesetIds: RULESETS.filter(r => !on.includes(r)) });
  await ls.remove('proPause'); chrome.alarms.clear('pro-resume'); renderPause();
}
document.querySelectorAll('[data-min]').forEach(b => { b.onclick = () => pause(Number(b.dataset.min)); });
$('#resumeNow').onclick = resume;

// ---------- request log ----------
const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
async function renderLog() {
  if (!DNR.onRuleMatchedDebug) { $('#logBody').textContent = 'The request log is only available when the extension is loaded unpacked.'; return; }
  const { proLog = [] } = await chrome.storage.session.get('proLog');
  $('#logBody').innerHTML = proLog.length
    ? '<table><tr><th>Time</th><th>Type</th><th>Ruleset</th><th>URL</th></tr>' + proLog.map(r =>
      '<tr><td>' + new Date(r.t).toLocaleTimeString() + '</td><td>' + esc(r.type) + '</td><td>' + esc(r.rs) + '</td><td>' + esc(r.url) + '</td></tr>').join('') + '</table>'
    : 'Nothing logged yet. Browse a page with ads and come back.';
}
$('#clearLog').onclick = async () => { await chrome.storage.session.remove('proLog'); renderLog(); };

// ---------- backup ----------
$('#exportBtn').onclick = async () => {
  const data = await ls.get(BACKUP_KEYS);
  const blob = new Blob([JSON.stringify({ app: 'AD BLOCKER PRO', version: 1, data }, null, 2)], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
  a.download = 'ad-blocker-pro-backup-' + new Date().toISOString().slice(0, 10) + '.json'; a.click();
  setMsg('#backupMsg', 'Backup downloaded.');
};
$('#importBtn').onclick = () => $('#importFile').click();
$('#importFile').onchange = async e => {
  try {
    const parsed = JSON.parse(await e.target.files[0].text());
    if (parsed.app !== 'AD BLOCKER PRO' || typeof parsed.data !== 'object') throw new Error('Not an AD BLOCKER PRO backup.');
    const data = {}; BACKUP_KEYS.forEach(k => { if (k in parsed.data) data[k] = parsed.data[k]; });
    await ls.set(data);
    setMsg('#backupMsg', 'Restored. Reloading the extension...');
    setTimeout(() => chrome.runtime.reload(), 900);
  } catch (err) { setMsg('#backupMsg', 'Import failed: ' + err.message, true); }
};
