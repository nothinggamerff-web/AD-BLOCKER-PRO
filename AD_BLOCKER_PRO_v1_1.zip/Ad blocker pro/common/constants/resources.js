"use strict";

// External website links removed. Empty values make the popup links do nothing.
const RESOURCES = {
  privacyUrl: '',
  termsUrl: '',
  cookiesUrl: '',
  redditUrl: '',
  facebookUrl: ''
};
