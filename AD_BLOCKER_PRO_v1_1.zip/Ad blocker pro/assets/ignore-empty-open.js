(function () {
  var nativeOpen = window.open;
  window.open = function (url) {
    if (!url) { return null; }
    return nativeOpen.apply(window, arguments);
  };
})();
