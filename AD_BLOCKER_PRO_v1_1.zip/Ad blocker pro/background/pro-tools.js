"use strict";
// AD BLOCKER PRO - extra tools (by IGRIS): custom cosmetic rules, pause timer, request log
(() => {
  const api = chrome, DNR = api.declarativeNetRequest;
  const RULESETS = ['requests', 'cookie-banners-requests', 'filter1-requests'];

  api.webNavigation.onCommitted.addListener(async d => {
    try {
      if (!/^https?:/.test(d.url)) return;
      const { proRules } = await api.storage.local.get('proRules');
      if (!proRules?.cosmetic?.length) return;
      const host = new URL(d.url).hostname;
      const sels = proRules.cosmetic
        .filter(r => !r.domains.length || r.domains.some(x => host === x || host.endsWith('.' + x)))
        .map(r => r.selector);
      if (!sels.length) return;
      await api.scripting.insertCSS({ target: { tabId: d.tabId, frameIds: [d.frameId] },
        css: sels.map(s => `${s}{display:none!important}`).join('\n') });
    } catch (e) { /* tab closed or restricted page */ }
  });

  async function resume() {
    const { userData } = await api.storage.local.get('userData');
    const s = userData?.settings || {};
    const on = [];
    if (s.enabled !== false) on.push('requests');
    if (s.hideCookieBanners) on.push('cookie-banners-requests');
    if (s.blockMalicious) on.push('filter1-requests');
    await DNR.updateEnabledRulesets({ enableRulesetIds: on, disableRulesetIds: RULESETS.filter(r => !on.includes(r)) });
    await api.storage.local.remove('proPause');
  }
  async function enforcePause() {
    const { proPause } = await api.storage.local.get('proPause');
    if (!proPause) return;
    if (proPause.until && proPause.until <= Date.now()) return resume();
    await DNR.updateEnabledRulesets({ disableRulesetIds: RULESETS });
    if (proPause.until) api.alarms.create('pro-resume', { when: proPause.until });
  }
  api.alarms.onAlarm.addListener(a => { if (a.name === 'pro-resume') resume().catch(() => {}); });
  setTimeout(() => enforcePause().catch(() => {}), 4000); // after the base app re-applies its own rulesets

  if (DNR.onRuleMatchedDebug) {
    let q = Promise.resolve();
    DNR.onRuleMatchedDebug.addListener(info => {
      q = q.then(async () => {
        const { proLog = [] } = await api.storage.session.get('proLog');
        proLog.unshift({ t: Date.now(), url: info.request.url, type: info.request.type, rs: info.rule.rulesetId });
        await api.storage.session.set({ proLog: proLog.slice(0, 300) });
      }).catch(() => {});
    });
  }
})();
