"use strict";

function matchesStackTrace(needleDetails, logLevel = '') {
  const safe = safeSelf();
  const exceptionToken = generateExceptionToken();
  const error = new safe.Error(exceptionToken);
  const docURL = new URL(self.location.href);
  docURL.hash = '';
  const reLine = /(.*?@)?(\S+)(:\d+):\d+\)?$/;
  const lines = [];
  for (let line of safe.String_split.call(error.stack, /[\n\r]+/)) {
    if (line.includes(exceptionToken)) {
      continue;
    }
    line = line.trim();
    const match = safe.RegExp_exec.call(reLine, line);
    if (match === null) {
      continue;
    }
    let url = match[2];
    if (url.startsWith('(')) {
      url = url.slice(1);
    }
    if (url === docURL.href) {
      url = 'inlineScript';
    } else if (url.startsWith('<anonymous>')) {
      url = 'injectedScript';
    }
    let fn = match[1] !== undefined ? match[1].slice(0, -1) : line.slice(0, match.index).trim();
    if (fn.startsWith('at')) {
      fn = fn.slice(2).trim();
    }
    const rowcol = match[3];
    lines.push(` ${`${fn} ${url}${rowcol}:1`.trim()}`);
  }
  lines[0] = `stackDepth:${lines.length - 1}`;
  const stack = lines.join('\t');
  const r = needleDetails.matchAll !== true && safe.testPattern(needleDetails, stack);
  if (logLevel === 'all' || logLevel === 'match' && r || logLevel === 'nomatch' && !r) {
    safe.stndzLog(stack.replace(/\t/g, '\n'));
  }
  return r;
}